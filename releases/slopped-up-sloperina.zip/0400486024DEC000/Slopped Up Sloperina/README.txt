Slopped Up Sloperina 0.2.1 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.5 installed as well.
Without Core it loads and does nothing.

Files:
  exefs/subsdk2  (10360 bytes)
