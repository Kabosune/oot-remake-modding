Slopped Up Sloperina 0.3.0 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.5 installed as well.
Without Core it loads and does nothing.

Files:
  LICENSE  (35149 bytes)
  SOURCE.txt  (510 bytes)
  exefs/subsdk2  (532920 bytes)
