Kaepora Core 0.2 (Ocarina of Time, Switch 2, game version 1.1.1)

With: Mouse Grab 0.2.0 (linked into Core's module)

Copy this folder into the emulator's load folder for the game, then close and reopen the
emulator. Only one mod folder with an exefs/subsdk1 can be on at a time: turn off older
Kaepora or Mouse Grab folders first.

Files:
  exefs/E0F3CCFAF50065AE4EA01EB5AEB13B1A45DA3348.ips  (141 bytes)
  exefs/subsdk1  (36472 bytes)
