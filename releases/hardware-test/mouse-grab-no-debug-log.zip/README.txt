Mouse Grab (no debug log) (Ocarina of Time, Switch 2)

Hardware test: Mouse Grab with Kaepora Core's debug log switched off (it never calls
svcOutputDebugString). Otherwise the same as mouse-grab-test.zip.

Install: copy the ns2jb-modloader folder in this zip to the root of the microSD card, merging
it with the one there. Only one test at a time: remove the previous test's files first
(ns2jb-modloader/exefs_patches/<its name>/ and ns2jb-modloader/contents/0400486024DEC000/).
Game version 1.1.1 only. Results: https://github.com/Kabosune/oot-remake-modding/issues/2
