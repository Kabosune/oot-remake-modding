Adventure Log 0.3.1 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.9 installed as well.
Without Core it loads and does nothing.
Adventure Log reads the game at offsets of its own: it runs only on the game version they're for.
Adventure Log was tested on game version 1.1.1.

Files:
  exefs/subsdk2  (479952 bytes)
