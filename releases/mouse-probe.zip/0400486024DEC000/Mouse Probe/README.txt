Mouse probe (Ocarina of Time, Switch 2, main build E0F3CCFA)

A test build for the mouse-grab mod. It changes nothing in the game. Twice a second it writes
a line starting with "MGP" to the emulator's log: the mouse state and the motion sensor state
the game can read. Remove it when the test is done.
