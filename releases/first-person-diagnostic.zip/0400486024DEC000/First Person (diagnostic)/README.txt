First Person (Ocarina of Time, Switch 2, main build E0F3CCFA)

Press R3 (click the right stick) to switch first person on or off.
Right stick looks around, left stick walks, everything else is the game's own.
Keyboard (turn on the emulator's keyboard emulation): ',' eye down, '.' eye up, '/' back to 0,
';' hide / show Link while in first person.
Each press moves the eye 2 cm. The offset stays until you restart the game.
Source and notes: see the repository this came from.
