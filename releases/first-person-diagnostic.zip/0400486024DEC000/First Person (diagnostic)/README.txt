First Person (Ocarina of Time, Switch 2, main build E0F3CCFA)

Press R3 (click the right stick) to switch first person on or off.
Right stick looks around, left stick walks, everything else is the game's own.
Source and notes: see the repository this came from.
