Mouse Grab, cursor test build (Ocarina of Time, Switch 2, game version 1.1.1)

Draws a cursor at the mouse position. In an emulator, turn on its emulated mouse.
exefs/subsdk1 is the whole mod; it patches nothing in main.
