Mouse Grab 0.2.0 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.4 installed as well.
Without Core it loads and does nothing.

Files:
  exefs/subsdk2  (15248 bytes)
