Mouse Grab 0.4.0 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.8 installed as well.
Without Core it loads and does nothing.
Mouse Grab was tested on game versions 1.0.0, 1.1.1.

Files:
  exefs/subsdk2  (20384 bytes)
