Mouse Grab, cursor test build (Ocarina of Time, Switch 2, game version 1.1.1)

Draws a cursor at the mouse position. Right click: Link ragdolls (test). In an emulator, turn
on its emulated mouse. exefs/subsdk1 is the mod; the .ips adds one hook point to main.
