FPV Drone (Ocarina of Time, Switch 2, main build E0F3CCFA)

L3 (click the left stick): on / off. It starts where the game camera is, in Free fly.
While it's on, Link stands still and the game doesn't see your controller.

Modes:
  L  Free fly    (noclip camera, the mode at boot): left stick moves where you look,
                  right stick looks, ZL / ZR down / up; no physics
  Y  Angle mode  (drone, self-levelling; stick = tilt angle)
  X  Acro mode   (drone, stick = rotation rate; no levelling, flips and rolls)
  B  Simple mode (drone, self-levelling, holds height; throttle = climb / sink, lets go = stops)

Drone sticks (Mode 2, like a radio):
  left stick  up / down = throttle, left / right = yaw
  right stick up / down = pitch,    left / right = roll
  Throttle: stick centred = hover, up = up to 3.5 g, down = less thrust.

Other buttons:
  R  carry Link: his feet at camera height, 1 m behind it (out of view); R again drops him
  A  back to the game camera
  + or -  leaves (so menus work; also drops Link)

No collision: it flies through walls and floors.
Source and notes: see the repository this came from.
