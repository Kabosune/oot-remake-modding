FPV Drone (Ocarina of Time, Switch 2, main build E0F3CCFA)

L3 (click the left stick): drone on / off. It takes off from where the game camera is.
While flying, Link stands still and the game doesn't see your controller.

Sticks (Mode 2, like a radio):
  left stick  up / down = throttle, left / right = yaw
  right stick up / down = pitch,    left / right = roll

Buttons while flying:
  Y  Angle mode  (self-levelling; stick = tilt angle)       <- starts in this one
  X  Acro mode   (stick = rotation rate; no levelling, flips and rolls)
  B  Simple mode (self-levelling, holds height; throttle = climb / sink, lets go = stops)
  A  back to the game camera
  + or -  leaves the drone (so menus work)

Throttle: stick centred = hover, up = up to 3.5 g, down = less thrust.
The drone has no collision: it flies through walls and floors.
Source and notes: see the repository this came from.
