KaeGae Core 0.8.1 (Ocarina of Time, Switch 2, game version 1.1.1)

Copy this folder into the emulator's load folder for the game, then close and reopen the
emulator. Only one mod folder with an exefs/subsdk1 can be on at a time: turn off older
KaeGae or Mouse Grab folders first.

Files:
  exefs/E0F3CCFAF50065AE4EA01EB5AEB13B1A45DA3348.ips  (199 bytes)
  exefs/subsdk1  (73248 bytes)
