World Tools 0.1.1 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.9 installed as well.
Without Core it loads and does nothing.
World Tools was tested on game version 1.1.1.

Files:
  exefs/subsdk2  (12424 bytes)
