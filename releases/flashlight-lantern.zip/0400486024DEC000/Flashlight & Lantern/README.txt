Flashlight & Lantern 0.1.2 (Ocarina of Time, Switch 2)

A KaeGae mod without KaeGae Core in the folder: it needs Core 0.9 installed as well.
Without Core it loads and does nothing.
Flashlight & Lantern reads the game at offsets of its own: it runs only on the game version they're for.
Flashlight & Lantern was tested on game version 1.1.1.

Files:
  exefs/subsdk2  (16072 bytes)
