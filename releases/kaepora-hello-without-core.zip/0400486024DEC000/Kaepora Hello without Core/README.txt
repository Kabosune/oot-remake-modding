Kaepora Hello WITHOUT Kaepora Core: a test, not a mod.

It answers one question: what does the game do when a core mod is installed and Core isn't?
Turn off every other folder with an exefs/subsdk1 (Kaepora Test, Mouse Grab) and sloperinaGZ,
copy this folder into the emulator's load folder, close and reopen the emulator, start the game.

Hoped for: the game starts as normal and the log has one line,
  kaepora mod: Kaepora Core isn't loaded (or this module wasn't linked to it); doing nothing
If the game stays at "starting...", the game's loader refuses a module with a missing import, and
mods will have to find Core another way.
